"use client";

import axios from "axios";
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "./components/button";
import { Input } from "./components/input";
import { Slider } from "./components/slider";

// Function to generate morphing video using Luma Dream Machine API
const generateMorphingVideo = async (object1: string, object2: string) => {
  const options = {
    method: "POST",
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_LUMA_API_KEY}`,
    },
    data: {
      prompt: `A morphing video transitioning from ${object1} to ${object2}`,
      // Add other necessary parameters as per Luma API documentation
    },
  };

  try {
    const response = await axios(
      "https://api.lumalabs.ai/dream-machine/v1/generations",
      options
    );
    console.log("Luma API Response:", response.data);
    return response.data.id; // Return the generation ID
  } catch (error) {
    console.error("Error generating morphing video:", error);
    throw error;
  }
};

// Function to get generation status and video URL
const getGenerationStatus = async (id: string) => {
  const options = {
    method: "GET",
    headers: {
      accept: "application/json",
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_LUMA_API_KEY}`,
    },
  };

  try {
    const response = await axios(
      `https://api.lumalabs.ai/dream-machine/v1/generations/${id}`,
      options
    );
    console.log("Luma API Status Response:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error getting generation status:", error);
    throw error;
  }
};

// Function to capture frame from video and return as blob
const captureFrame = (video: HTMLVideoElement): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas
        .getContext("2d")
        ?.drawImage(video, 0, 0, canvas.width, canvas.height);

      canvas.toBlob(
        (blob) => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error("Failed to create blob from canvas"));
          }
        },
        "image/jpeg",
        0.95
      );
    } catch (error) {
      reject(error);
    }
  });
};

// Function to upload image to server
const uploadToServer = async (imageBlob: Blob): Promise<string> => {
  console.log("Uploading image to server...");
  const formData = new FormData();
  formData.append("image", imageBlob);

  try {
    const response = await axios.post("/api/upload", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    console.log("Server upload response:", response.data);
    return response.data.url;
  } catch (error) {
    console.error("Error uploading image to server:", error);
    throw error;
  }
};

const generate3DObject = async (imageBlob: Blob) => {
  try {
    // Upload the image to our server and get the public URL
    console.log("Starting server upload process...");
    const publicImageUrl = await uploadToServer(imageBlob);
    console.log("Image uploaded to server. Public URL:", publicImageUrl);

    const headers = {
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_MESHY_API_KEY}`,
      "Content-Type": "application/json",
    };
    const payload = {
      image_url: publicImageUrl,
      enable_pbr: true,
    };

    console.log("Meshy API Request:", {
      ...payload,
      image_url: publicImageUrl,
    });
    const createResponse = await axios.post(
      "https://api.meshy.ai/v1/image-to-3d",
      payload,
      { headers }
    );
    console.log("Meshy API Create Response:", createResponse.data);
    const taskId = createResponse.data.result;

    // Poll for task completion
    let taskCompleted = false;
    let modelData;
    while (!taskCompleted) {
      const statusResponse = await axios.get(
        `https://api.meshy.ai/v1/image-to-3d/${taskId}`,
        { headers }
      );
      console.log("Meshy API Status Response:", statusResponse.data);
      const taskStatus = statusResponse.data;

      if (taskStatus.status === "SUCCEEDED") {
        taskCompleted = true;
        modelData = taskStatus;
      } else if (taskStatus.status === "FAILED") {
        throw new Error("3D object generation failed");
      } else {
        // Wait for 5 seconds before checking again
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }

    return modelData;
  } catch (error) {
    console.error("Error generating 3D object:", error);
    throw error;
  }
};

export default function Component() {
  const [step, setStep] = useState(1);
  const [object1, setObject1] = useState("");
  const [object2, setObject2] = useState("");
  const [generationId, setGenerationId] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [selectedFrame, setSelectedFrame] = useState(0);
  const [object3DData, setObject3DData] = useState<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleGenerate = async () => {
    setStep(2);
    try {
      const id = await generateMorphingVideo(object1, object2);
      setGenerationId(id);
    } catch (error) {
      console.error("Error in handleGenerate:", error);
      setStep(1);
    }
  };

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    if (generationId) {
      intervalId = setInterval(async () => {
        try {
          const status = await getGenerationStatus(generationId);
          if (status.state === "completed") {
            setVideoUrl(status.assets.video);
            setStep(3);
            clearInterval(intervalId);
          } else if (status.state === "failed") {
            console.error("Generation failed:", status.failure_reason);
            setStep(1);
            clearInterval(intervalId);
          }
        } catch (error) {
          console.error("Error checking generation status:", error);
          setStep(1);
          clearInterval(intervalId);
        }
      }, 5000); // Check every 5 seconds
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [generationId]);

  const handleGenerate3D = useCallback(async () => {
    setStep(4);
    try {
      if (!videoRef.current) {
        throw new Error("Video reference is not available");
      }
      const capturedFrameBlob = await captureFrame(videoRef.current);
      console.log("Captured Frame Blob:", capturedFrameBlob);
      const object3D = await generate3DObject(capturedFrameBlob);
      setObject3DData(object3D);
      setStep(5);
    } catch (error) {
      console.error("Error in handleGenerate3D:", error);
      setStep(3);
    }
  }, []);

  const handleSliderChange = (value: number[]) => {
    setSelectedFrame(value[0]);
    if (videoRef.current) {
      videoRef.current.currentTime = value[0];
    }
  };

  const handleVideoTimeUpdate = () => {
    if (videoRef.current) {
      setSelectedFrame(videoRef.current.currentTime);
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <div className="flex-grow flex items-center justify-center bg-gray-100">
        {step === 1 && (
          <div className="text-center text-2xl text-gray-500">
            Enter objects below to start
          </div>
        )}
        {step === 2 && (
          <div className="text-2xl">Generating morphing video...</div>
        )}
        {step === 3 && (
          <div className="w-full h-full flex items-center justify-center">
            <video
              className="w-3/4 h-3/4"
              controls
              src={videoUrl}
              ref={videoRef}
              onTimeUpdate={handleVideoTimeUpdate}
              crossOrigin="anonymous"
            >
              Your browser does not support the video tag.
            </video>
          </div>
        )}
        {step === 4 && <div className="text-2xl">Generating 3D object...</div>}
        {step === 5 && (
          <div className="w-full h-full flex items-center justify-center">
            <div className="w-3/4 h-3/4 bg-gray-200 flex flex-col items-center justify-center text-xl">
              <a href={object3DData?.model_urls?.glb} download className="mb-2">
                Download GLB
              </a>
              <a href={object3DData?.model_urls?.fbx} download className="mb-2">
                Download FBX
              </a>
              <a
                href={object3DData?.model_urls?.usdz}
                download
                className="mb-2"
              >
                Download USDZ
              </a>
              <a href={object3DData?.thumbnail_url} download className="mb-2">
                Download Thumbnail
              </a>
              {object3DData?.texture_urls?.map(
                (texture: any, index: number) => (
                  <div key={index} className="mb-2">
                    <a href={texture.base_color} download className="mr-2">
                      Base Color
                    </a>
                    <a href={texture.metallic} download className="mr-2">
                      Metallic
                    </a>
                    <a href={texture.normal} download className="mr-2">
                      Normal
                    </a>
                    <a href={texture.roughness} download>
                      Roughness
                    </a>
                  </div>
                )
              )}
            </div>
          </div>
        )}
      </div>
      <div className="bg-white p-4 shadow-md">
        <div className="flex space-x-4 items-center">
          {step === 1 && (
            <>
              <Input
                placeholder="First object (e.g. Butterfly)"
                value={object1}
                onChange={(e) => setObject1(e.target.value)}
                className="flex-grow"
              />
              <Input
                placeholder="Second object (e.g. Spaceship)"
                value={object2}
                onChange={(e) => setObject2(e.target.value)}
                className="flex-grow"
              />
              <Button onClick={handleGenerate}>Generate Video</Button>
            </>
          )}
          {step === 3 && (
            <>
              <div className="flex-grow flex items-center space-x-2">
                <Slider
                  min={0}
                  max={videoRef.current ? videoRef.current.duration : 10}
                  step={0.1}
                  value={[selectedFrame]}
                  onValueChange={handleSliderChange}
                  className="flex-grow"
                />
                <span className="text-sm text-gray-500">
                  {selectedFrame.toFixed(1)}s
                </span>
              </div>
              <Button onClick={handleGenerate3D}>Generate 3D</Button>
            </>
          )}
          {step === 5 && (
            <Button onClick={() => setStep(1)} className="ml-auto">
              Start Over
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
